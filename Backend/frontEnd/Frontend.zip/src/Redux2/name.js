export default 'ADMIN';
