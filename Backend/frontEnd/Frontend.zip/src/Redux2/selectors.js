import DomainName from './name'

export const featureSelector = state => state[DomainName];