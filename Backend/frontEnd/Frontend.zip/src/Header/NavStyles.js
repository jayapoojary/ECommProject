export default theme => ({
    navStyle : () => ({
        padding: '5px',
        color: 'white'
    }),
    divStyle: () => ({
        height: '66px',
        backgroundColor: 'skyBlue',
        zIndex: 1000,
        width: '100%',
        top: '0px',
    })
})