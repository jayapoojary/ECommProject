export const createActionName = (prefix, actionName) =>
  `${prefix}/${actionName}`;
