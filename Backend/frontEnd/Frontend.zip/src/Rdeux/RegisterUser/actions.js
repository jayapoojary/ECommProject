export const REGISTER_USER = 'REGISTER_USER';

export const actions = payload => {
    return {
        type: REGISTER_USER,
        payload,
    }
}